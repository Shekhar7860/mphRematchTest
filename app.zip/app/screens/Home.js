import React from 'react'
import {View, Text} from 'react-native';

export default Home = () => {
	return (<View><Text>This is Home Screen </Text></View>)
}