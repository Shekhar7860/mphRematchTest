import React from 'react'
import {View, Text, Button} from 'react-native';

export default Chat = (props) => {
	return (<View><Text>This is Chat Screen </Text>
         <Button title="OpenDrawer" onPress={() => props.navigation.openDrawer()}></Button>
		</View>)
}