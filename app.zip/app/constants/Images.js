export const rightArrow = require('../images/arrow_right.png');
export const TEST = require('../images/Test.png');
export const PROFILE_PIC = require('../images/Profile-white.png');
export const HELP_STEP_2 = require('../images/Test_1.png');
export const HELP_STEP_3 = require('../images/Test_2.png');

